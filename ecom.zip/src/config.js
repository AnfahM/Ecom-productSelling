// config.js
const config = {
  API_BASE_URL: "https://anfahm.pythonanywhere.com", // Updated to your PythonAnywhere IP link
};

export default config;
